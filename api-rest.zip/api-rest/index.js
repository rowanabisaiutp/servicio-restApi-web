const mysql = require('mysql');
const express = require('express');
const nodemon = require('nodemon');
var app = express();

const bodyParser = require('body-parser');
app.use(bodyParser.json());

var mysqlConnction = mysql.createConnection({
    host: 'localHost',
    database:'Empleados',
    user: 'root',
    password: '',
    multiplaStatements: true
});

mysqlConnction.connect((err) => {
    if(!err)
    console.log('conexion a la base de datos exitosa');
    else{
        console.log('conexion no establecida: ' + JSON.stringify(err, undefined, 2));
    }
});

app.listen(3000, () => console.log('Servidor corriendo en el puerto: 3000'));

//app.get('');

app.get('/empleado', (req, res) => {
    mysqlConnction.query('SELECT * FROM Empleado', (err, rows, fields) => {
        if(!err)
            res.send(rows).toString();
            else
            console.log(err);  
    })
});

//app.get('') y empleados;

app.get('/empleado/:id', (req, res) => {
    mysqlConnction.query('SELECT * FROM Empleado  WHERE EmpID = ?',[req.params.id], (err, rows, fields) => {
        if(!err)
            res.send(rows).toString();
            else
            console.log(err);  
    })
});

// delete

app.delete('/empleado/:id', (req, res) => {
    mysqlConnction.query('DELETE FROM Empleado WHERE EmpID = ?',[req.params.id], (err, rows, fields) => {
        if(!err)
            res.send('Se ekimino correctamente');
            else
            console.log(err);  
    })
});

/*
    --EmpId--               (INT NOT NULL AUTO_INCREMENT),
    --Nombre--              (VARCHAR(45)),
   --Apellido--             (VARCHAR(45)),
     --Edad--               (NUMERIC),
*/

app.post('/empleado/:id', (req, res) => {
    let emp = req.body;
    /*
    CREATE TABLE Empleado(
        EmpId INT NOT NULL AUTO_INCREMENT,
        Nombre VARCHAR(45),
        Apellido VARCHAR(45),
        Edad NUMERIC,
        ------PRIMARY KEY (`EmpId`)-------
        );
    */

    var sql = "SET @EmpID = ?; SET @Nombre = ?; SET @Apellido = ?; SET @Edad = ?; \
    CALL EmpleadoAddOrEdit(@EmpId,@Nombre,@Apellido,@Edad);";
    mysqlConnction.query(sql,[emp.EmpId, emp.Nombre, emp.Apellido, emp.Edad], (err, rows, fields) => {
        if(!err)
            rows.array.array.forEach(element => {
                if(element.constructor == Array)
                res.send('Insertar nuevo empleadoo: ' + eleme[0].EmpId);
            });
            else
            console.log(err);  
    })
});

//Actualizar empleado

app.put('/empleado/:id', (req, res) => {
    let emp = req.body;

    var sql = "SET @EmpID = ?; SET @Nombre = ?; SET @Apellido = ?; SET @Edad = ?; \
    CALL EmpleadoAddOrEdit(@EmpId,@Nombre,@Apellido,@Edad);";
    mysqlConnction.query(sql,[emp.EmpId, emp.Nombre, emp.Apellido, emp.Edad], (err, rows, fields) => {
        if(!err)
            rows.array.array.forEach(element => {
                if(element.constructor == Array)
                res.send('Actualizacion exitosa');
            });
            else
            console.log(err);  
    })
});