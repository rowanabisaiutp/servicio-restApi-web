CREATE DATABASE Empleados;
USE Empleados;

CREATE TABLE Empleado(
EmpId INT NOT NULL AUTO_INCREMENT,
Nombre VARCHAR(45),
Apellido VARCHAR(45),
Edad NUMERIC,
PRIMARY KEY (`EmpId`)
);

INSERT INTO `Empleado` VALUES (1, 'Rowan', 'Ojeda Kumul', 21);
INSERT INTO `Empleado` VALUES (2, 'Rowan', 'Ojeda Kumul', 21);
INSERT INTO `Empleado` VALUES (3, 'carlos', 'gomez gonzales', 25);

SELECT * FROM Empleado;